package com.example.projectthree;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}

// DatabaseHelper.java
public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "cap_cut";
    private static final int DATABASE_VERSION = 1;

    // Define table and column names
    private static final String TABLE_NAME = "create_user";
    private static final String COLUMN_ID = "user_id";
    private static final String COLUMN_ITEM_NAME = "delete_user";
    private static final String COLUMN_ITEM_QUANTITY = "update_user";


    // SQL statement for creating the table
    private static final String CREATE_TABLE =
            "CREATE TABLE " + TABLE_NAME + " (" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_ITEM_NAME + " TEXT, " +
                    COLUMN_ITEM_QUANTITY + " INTEGER);";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Handle database upgrade if needed
    }

    // Insert data into the database
    public long insertData(String itemName, int itemQuantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_ITEM_NAME, itemName);
        values.put(COLUMN_ITEM_QUANTITY, itemQuantity);
        long newRowId = db.insert(TABLE_NAME, null, values);
        db.close();
        return newRowId;
    }

    // Update data in the database
    public int updateData(long id, String itemName, int itemQuantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_ITEM_NAME, itemName);
        values.put(COLUMN_ITEM_QUANTITY, itemQuantity);
        int numRowsAffected = db.update(TABLE_NAME, values, COLUMN_ID + " = ?",
                new String[]{String.valueOf(id)});
        db.close();
        return numRowsAffected;
    }

    // Delete data from the database
    public int deleteData(long id) {
        SQLiteDatabase db = this.getWritableDatabase();
        int numRowsAffected = db.delete(TABLE_NAME, COLUMN_ID + " = ?",
                new String[]{String.valueOf(id)});
        db.close();
        return numRowsAffected;
    }

    // Get all data from the database
    public Cursor getAllData() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TABLE_NAME, null, null, null, null, null, null);
    }
}

}

// DataDisplayActivity.java
public class DataDisplayActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private DatabaseHelper databaseHelper;
    private CustomAdapter customAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_display);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        databaseHelper = new DatabaseHelper(this);
        customAdapter = new CustomAdapter(getDataFromDatabase(), this);
        recyclerView.setAdapter(customAdapter);
    }

    // Method to fetch data from the database
    private List<DataModel> getDataFromDatabase() {
        List<DataModel> data = new ArrayList<>();

        // Assuming DataModel is a class representing the structure of your data
        Cursor cursor = databaseHelper.getAllData();
        if (cursor != null && cursor.moveToFirst()) {
            do {
                long id = cursor.getLong(cursor.getColumnIndex("id"));
                String itemName = cursor.getString(cursor.getColumnIndex("item_name"));
                int itemQuantity = cursor.getInt(cursor.getColumnIndex("item_quantity"));

                DataModel dataModel = new DataModel(id, itemName, itemQuantity);
                data.add(dataModel);
            } while (cursor.moveToNext());

            cursor.close();
        }

        return data;
    }
}
