import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class PermissionActivity extends AppCompatActivity {

    private static final int PERMISSION_REQUEST_CODE = 100;
    private Button btnRequestPermission;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_permission);

        // Initialize UI elements
        btnRequestPermission = findViewById(R.id.btnRequestPermission);

        // Set onClickListener for the Request Permission button
        btnRequestPermission.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View view) {
                // Check if the app has the necessary permission
                if (checkPermission()) {
                    // Permission already granted, you can perform your actions that require this permission
                    // For example, start a new activity or show a message
                    showToast("Permission already granted");
                } else {
                    // Request the permission
                    requestPermission();
                }
            }
        });
    }

    // Check if the app has the necessary permission
    private boolean checkPermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.YOUR_PERMISSION) == PackageManager.PERMISSION_GRANTED;
    }

    // Request the necessary permission
    @RequiresApi(api = Build.VERSION_CODES.M)
    private void requestPermission() {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.YOUR_PERMISSION}, PERMISSION_REQUEST_CODE);
    }

    // Handle the result of the permission request
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, you can perform your actions that require this permission
                // For example, start a new activity or show a message
                showToast("Permission granted");
            } else {
                // Permission denied, show a message or take appropriate action
                showToast("Permission denied");
            }
        }
    }

    // Helper method to show a toast message
    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
